import { useMemo, useState } from "react"

type Page = "home" | "recipes" | "regions" | "about" | "contact"
type IconName = "arrow" | "bookmark" | "chevron" | "close" | "heart" | "menu" | "moon" | "search" | "sun"

const photos = {
  egusi:
    "https://images.unsplash.com/photo-1763048443535-1243379234e2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1400",
  injera:
    "https://images.unsplash.com/photo-1765338915553-6e02fe63ff4f?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000",
  tagine:
    "https://images.unsplash.com/photo-1643019237176-8ae0859f1123?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000",
  feast:
    "https://images.unsplash.com/photo-1517314626714-ac1b9a16515e?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1400",
  rice: "https://images.unsplash.com/photo-1626266800006-5f5ca8204027?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000",
  stew: "https://images.unsplash.com/photo-1542627501-cadbb5b43ad7?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000",
  culture:
    "https://images.unsplash.com/photo-1663919402819-afebaad0849a?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1400",
  cooking:
    "https://images.unsplash.com/photo-1760907949894-b66d728e0a8e?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000",
}

const recipes = [
  {
    name: "Jollof Rice",
    place: "West Africa",
    region: "West",
    time: "55 min",
    image: photos.rice,
    tag: "Celebration",
  },
  {
    name: "Injera & Misir Wot",
    place: "Ethiopia",
    region: "East",
    time: "1 hr 20",
    image: photos.injera,
    tag: "Heritage",
  },
  {
    name: "Isombe",
    place: "Rwanda",
    region: "East",
    time: "50 min",
    image: photos.stew,
    tag: "Plant-forward",
  },
  {
    name: "Moroccan Tagine",
    place: "Morocco",
    region: "North",
    time: "1 hr 35",
    image: photos.tagine,
    tag: "Slow cooked",
  },
  {
    name: "Egusi Soup",
    place: "Nigeria",
    region: "West",
    time: "1 hr",
    image: photos.egusi,
    tag: "Comfort food",
  },
  {
    name: "Cape Malay Curry",
    place: "South Africa",
    region: "South",
    time: "1 hr 10",
    image: photos.feast,
    tag: "Aromatic",
  },
]

function Icon({ name, filled = false }: { name: IconName filled?: boolean }) {
  const common = {
    fill: filled ? "currentColor" : "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  }
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
        <path d="M19 12H5" />
      </>
    ),
    bookmark: (
      <path d="M6 4.8A1.8 1.8 0 0 1 7.8 3h8.4A1.8 1.8 0 0 1 18 4.8V21l-6-3.8L6 21V4.8Z" />
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    close: (
      <>
        <path d="m6 6 12 12" />
        <path d="M18 6 6 18" />
      </>
    ),
    heart: (
      <path d="M20.8 5.8a5.4 5.4 0 0 0-7.6 0L12 7l-1.2-1.2a5.4 5.4 0 0 0-7.6 7.6L12 22l8.8-8.6a5.4 5.4 0 0 0 0-7.6Z" />
    ),
    menu: (
      <>
        <path d="M4 7h16" />
        <path d="M4 12h16" />
        <path d="M4 17h16" />
      </>
    ),
    moon: (
      <path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5 8.5 8.5 0 1 0 20.5 14.2Z" />
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="3.5" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
  }
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" {...common}>
      {paths[name]}
    </svg>
  )
}

function Mark() {
  return (
    <span className="mark" aria-hidden="true">
      <i />
      <i />
      <i />
    </span>
  )
}

export default function App() {
  const [page, setPage] = useState<Page>("home")
  const [dark, setDark] = useState(true)
  const [menu, setMenu] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [region, setRegion] = useState("All")
  const [favorites, setFavorites] = useState<string[]>(["Injera & Misir Wot"])

  const go = (next: Page) => {
    setPage(next)
    setMenu(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const toggleFavorite = (name: string) => {
    setFavorites((current) =>
      current.includes(name)
        ? current.filter((item) => item !== name)
        : [...current, name],
    )
  }

  const shownRecipes = useMemo(
    () =>
      recipes.filter(
        (recipe) =>
          (region === "All" || recipe.region === region) &&
          `${recipe.name} ${recipe.place} ${recipe.tag}`
            .toLowerCase()
            .includes(query.toLowerCase()),
      ),
    [query, region],
  )

  return (
    <div className={dark ? "site dark" : "site light"}>
      <header className="header">
        <button
          className="brand"
          onClick={() => go("home")}
          aria-label="Tastes of Africa home"
        >
          <Mark />
          <span>
            Tastes <em>of</em> Africa
          </span>
        </button>
        <nav
          className={menu ? "nav open" : "nav"}
          aria-label="Primary navigation"
        >
          {(["home", "recipes", "regions", "about", "contact"] as Page[]).map(
            (item) => (
              <button
                key={item}
                className={page === item ? "active" : ""}
                onClick={() => go(item)}
              >
                {item === "about"
                  ? "About Us"
                  : item[0].toUpperCase() + item.slice(1)}
              </button>
            ),
          )}
        </nav>
        <div className="header-actions">
          <button
            className="icon-button"
            aria-label="Search recipes"
            onClick={() => setSearchOpen(true)}
          >
            <Icon name="search" />
          </button>
          <button
            className="theme-toggle"
            aria-label={`Switch to ${dark ? "light" : "dark"} mode`}
            onClick={() => setDark(!dark)}
          >
            <Icon name={dark ? "sun" : "moon"} />
          </button>
          <button
            className="menu-button"
            aria-label="Toggle menu"
            onClick={() => setMenu(!menu)}
          >
            <Icon name={menu ? "close" : "menu"} />
          </button>
        </div>
      </header>

      {page === "home" && (
        <Home go={go} favorites={favorites} toggleFavorite={toggleFavorite} />
      )}
      {page === "recipes" && (
        <RecipesPage
          favorites={favorites}
          query={query}
          region={region}
          recipes={shownRecipes}
          setQuery={setQuery}
          setRegion={setRegion}
          toggleFavorite={toggleFavorite}
        />
      )}
      {page === "regions" && <RegionsPage go={go} />}
      {page === "about" && <AboutPage />}
      {page === "contact" && <ContactPage />}

      <Footer go={go} />

      {searchOpen && (
        <div
          className="search-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Search recipes"
        >
          <button
            className="search-close icon-button"
            aria-label="Close search"
            onClick={() => setSearchOpen(false)}
          >
            <Icon name="close" />
          </button>
          <div className="search-panel">
            <span className="eyebrow">Find your next flavor</span>
            <h2>What are you craving?</h2>
            <label className="search-field">
              <Icon name="search" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search dishes, places, ingredients..."
              />
              <button
                onClick={() => {
                  setSearchOpen(false)
                  go("recipes")
                }}
              >
                Search
              </button>
            </label>
            <p>Popular: Jollof rice · Tagine · Ethiopian · Plant-forward</p>
          </div>
        </div>
      )}
    </div>
  )
}

function Home({
  go,
  favorites,
  toggleFavorite,
}: {
  go: (page: Page) => void
  favorites: string[]
  toggleFavorite: (name: string) => void
}) {
  const featured = recipes.slice(0, 4)
  return (
    <main>
      <section className="hero">
        <div className="hero-orb" />
        <div className="hero-copy">
          <span className="eyebrow">A culinary journey across a continent</span>
          <h1>
            Discover the rich <em>flavors</em> of Africa.
          </h1>
          <p>
            Stories, recipes and traditions from the cooks and communities who
            shape Africa’s extraordinary culinary landscape.
          </p>
          <div className="hero-buttons">
            <button className="button primary" onClick={() => go("recipes")}>
              Explore recipes <Icon name="arrow" />
            </button>
            <button className="button ghost" onClick={() => go("regions")}>
              Discover regions
            </button>
          </div>
          <div className="hero-note">
            <span>54</span>
            <p>
              countries,
              <br />
              endless stories
            </p>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-image-wrap">
            <img
              src={photos.egusi}
              alt="Hands presenting a vibrant bowl of African cuisine"
            />
            <div className="image-caption">
              <span>Featured story</span>
              <strong>
                The soul of the
                <br />
                West African table
              </strong>
            </div>
          </div>
          <div className="spice-dot dot-one" />
          <div className="spice-dot dot-two" />
        </div>
        <p className="vertical-copy">Recipes · People · Places</p>
      </section>

      <section className="floating-section">
        <div className="section-heading light-heading">
          <div>
            <span className="eyebrow">Taste the continent</span>
            <h2>
              Four dishes.
              <br />
              <em>Four stories.</em>
            </h2>
          </div>
          <p>
            From smoky celebration rice to slow-simmered stews, begin with the
            dishes that bring people together.
          </p>
        </div>
        <div className="floating-grid">
          {featured.map((recipe, index) => (
            <article
              className={`floating-card card-${index + 1}`}
              key={recipe.name}
            >
              <div className="card-image">
                <img src={recipe.image} alt={recipe.name} />
                <span>0{index + 1}</span>
              </div>
              <div className="card-body">
                <div>
                  <p>{recipe.place}</p>
                  <h3>{recipe.name}</h3>
                </div>
                <button
                  className={
                    favorites.includes(recipe.name)
                      ? "favorite active"
                      : "favorite"
                  }
                  onClick={() => toggleFavorite(recipe.name)}
                  aria-label={`Favorite ${recipe.name}`}
                >
                  <Icon name="heart" filled={favorites.includes(recipe.name)} />
                </button>
              </div>
            </article>
          ))}
        </div>
        <button className="text-link" onClick={() => go("recipes")}>
          View all recipes <Icon name="arrow" />
        </button>
      </section>

      <section className="tradition">
        <div className="tradition-image">
          <img
            src={photos.culture}
            alt="A cook preparing food in a traditional wok"
          />
          <span className="stamp">
            Shared
            <br />
            with love
          </span>
        </div>
        <div className="tradition-copy">
          <span className="eyebrow">More than a meal</span>
          <h2>
            Food is our
            <br />
            <em>living archive.</em>
          </h2>
          <p className="lead">
            Every pot carries memory. Every ingredient maps a journey. Every
            shared plate keeps a story alive.
          </p>
          <p>
            Across Africa, food is an expression of place and belonging—from
            grains cultivated across generations to spice routes that
            transformed entire coastlines.
          </p>
          <button className="button ink" onClick={() => go("about")}>
            Our story <Icon name="arrow" />
          </button>
        </div>
      </section>

      <section className="region-strip">
        <div className="region-intro">
          <span className="eyebrow">Explore by place</span>
          <h2>
            A continent
            <br />
            of <em>flavor.</em>
          </h2>
        </div>
        {[
          ["01", "West Africa", "Bold · smoky · soulful"],
          ["02", "East Africa", "Spiced · bright · communal"],
          ["03", "North Africa", "Fragrant · slow · layered"],
          ["04", "Southern Africa", "Fire · field · fusion"],
        ].map(([number, name, text]) => (
          <button
            className="region-row"
            key={name}
            onClick={() => go("regions")}
          >
            <span>{number}</span>
            <strong>{name}</strong>
            <small>{text}</small>
            <i>
              <Icon name="arrow" />
            </i>
          </button>
        ))}
      </section>

      <section className="journal">
        <div className="journal-title">
          <span className="eyebrow">From the journal</span>
          <h2>
            Stories from
            <br />
            the <em>table.</em>
          </h2>
        </div>
        <article className="journal-feature">
          <img src={photos.cooking} alt="Woman cooking over an outdoor fire" />
          <div>
            <span>People & traditions</span>
            <h3>The women who keep the fire burning</h3>
            <p>
              Meet the cooks preserving technique, memory and community through
              the everyday ritual of food.
            </p>
            <a href="#story" onClick={(e) => e.preventDefault()}>
              Read the story <Icon name="arrow" />
            </a>
          </div>
        </article>
        <article className="journal-small">
          <img src={photos.injera} alt="Colorful Ethiopian shared platter" />
          <div>
            <span>Ingredient guide</span>
            <h3>Teff: a tiny grain with an ancient story</h3>
          </div>
        </article>
      </section>
    </main>
  )
}

function RecipeCard({
  recipe,
  saved,
  toggle,
}: {
  recipe: typeof recipes[number]
  saved: boolean
  toggle: () => void
}) {
  return (
    <article className="recipe-card">
      <div className="recipe-photo">
        <img src={recipe.image} alt={recipe.name} />
        <button
          className={saved ? "favorite active" : "favorite"}
          onClick={toggle}
          aria-label={`Favorite ${recipe.name}`}
        >
          <Icon name="heart" filled={saved} />
        </button>
        <span>{recipe.tag}</span>
      </div>
      <div className="recipe-info">
        <p>
          {recipe.place} · {recipe.time}
        </p>
        <h3>{recipe.name}</h3>
        <button>
          View recipe <Icon name="arrow" />
        </button>
      </div>
    </article>
  )
}

function RecipesPage(props: {
  favorites: string[]
  query: string
  region: string
  recipes: typeof recipes
  setQuery: (value: string) => void
  setRegion: (value: string) => void
  toggleFavorite: (name: string) => void
}) {
  return (
    <main className="inner-page recipes-page">
      <section className="page-hero">
        <span className="eyebrow">The recipe collection</span>
        <h1>
          Cook your way
          <br />
          across <em>Africa.</em>
        </h1>
        <p>
          Explore deeply researched recipes, cultural context and the techniques
          that make each dish distinct.
        </p>
      </section>
      <section className="recipe-browser">
        <div className="browser-top">
          <label className="inline-search">
            <Icon name="search" />
            <input
              value={props.query}
              onChange={(e) => props.setQuery(e.target.value)}
              placeholder="Search the collection"
            />
          </label>
          <p>{props.recipes.length} recipes to explore</p>
        </div>
        <div className="filter-row">
          {["All", "West", "East", "North", "South"].map((item) => (
            <button
              key={item}
              className={props.region === item ? "active" : ""}
              onClick={() => props.setRegion(item)}
            >
              {item === "All" ? "All regions" : `${item} Africa`}
            </button>
          ))}
        </div>
        {props.recipes.length ? (
          <div className="recipe-grid">
            {props.recipes.map((recipe) => (
              <RecipeCard
                key={recipe.name}
                recipe={recipe}
                saved={props.favorites.includes(recipe.name)}
                toggle={() => props.toggleFavorite(recipe.name)}
              />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h2>No recipes found</h2>
            <p>Try another dish, place or region.</p>
            <button
              className="button primary"
              onClick={() => {
                props.setQuery("")
                props.setRegion("All")
              }}
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
    </main>
  )
}

function RegionsPage({ go }: { go: (page: Page) => void }) {
  const regions = [
    [
      "West Africa",
      "From Senegalese thieboudienne to Nigerian soups, discover cuisines built on smoke, spice, grains and generosity.",
      photos.egusi,
    ],
    [
      "East Africa",
      "Follow the scent of berbere, cardamom and charcoal through highland tables and Indian Ocean kitchens.",
      photos.injera,
    ],
    [
      "North Africa",
      "Explore a meeting point of Amazigh, Arab, Mediterranean and sub-Saharan culinary traditions.",
      photos.tagine,
    ],
    [
      "Southern Africa",
      "Discover fire-led cooking, indigenous ingredients and the layered histories of the southern table.",
      photos.feast,
    ],
  ]
  return (
    <main className="inner-page">
      <section className="page-hero">
        <span className="eyebrow">Culinary atlas</span>
        <h1>
          Follow the flavors
          <br />
          <em>across Africa.</em>
        </h1>
        <p>
          Learn through ingredients, climates, migrations and the people who
          make each region distinctive.
        </p>
      </section>
      <section className="regions-grid">
        {regions.map(([name, description, image], i) => (
          <article key={name}>
            <img src={image} alt={`${name} cuisine`} />
            <span>0{i + 1}</span>
            <div>
              <h2>{name}</h2>
              <p>{description}</p>
              <button onClick={() => go("recipes")}>
                Explore dishes <Icon name="arrow" />
              </button>
            </div>
          </article>
        ))}
      </section>
    </main>
  )
}

function AboutPage() {
  return (
    <main className="inner-page about-page">
      <section className="page-hero">
        <span className="eyebrow">Our purpose</span>
        <h1>
          Every recipe is
          <br />
          <em>a record.</em>
        </h1>
        <p>
          We document Africa’s food cultures with care, curiosity and respect
          for the people who carry them forward.
        </p>
      </section>
      <section className="about-editorial">
        <img src={photos.culture} alt="Traditional cooking in progress" />
        <div>
          <span className="eyebrow">Why we’re here</span>
          <h2>A richer picture of African food.</h2>
          <p>
            Tastes of Africa is an independent culinary discovery platform
            dedicated to the depth and diversity of a continent too often
            reduced to a handful of dishes.
          </p>
          <p>
            We connect recipes to the landscapes, histories and communities that
            shaped them. Our work celebrates tradition without treating it as
            static—because food culture has always moved, adapted and grown.
          </p>
          <blockquote>
            “To learn a cuisine is to learn how a people remember.”
          </blockquote>
        </div>
      </section>
    </main>
  )
}

function ContactPage() {
  const [sent, setSent] = useState(false)
  return (
    <main className="inner-page contact-page">
      <section className="page-hero">
        <span className="eyebrow">Let’s share stories</span>
        <h1>
          Pull up
          <br />
          <em>a chair.</em>
        </h1>
        <p>
          Have a family recipe, a correction or an idea for a story? We’d love
          to hear from you.
        </p>
      </section>
      <section className="contact-card">
        <div>
          <h2>Start a conversation.</h2>
          <p>
            We welcome recipe submissions, collaborations and thoughtful notes
            from readers everywhere.
          </p>
          <a href="mailto:hello@tastesofafrica.com">hello@tastesofafrica.com</a>
        </div>
        {sent ? (
          <div className="thanks">
            <span>Thank you</span>
            <h2>Your note is on its way.</h2>
            <p>We’ll be in touch soon.</p>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setSent(true)
            }}
          >
            <label>
              Name
              <input required placeholder="Your name" />
            </label>
            <label>
              Email
              <input required type="email" placeholder="you@example.com" />
            </label>
            <label>
              Message
              <textarea
                required
                rows={5}
                placeholder="Tell us what’s on your mind..."
              />
            </label>
            <button className="button primary">
              Send message <Icon name="arrow" />
            </button>
          </form>
        )}
      </section>
    </main>
  )
}

function Footer({ go }: { go: (page: Page) => void }) {
  return (
    <footer>
      <div className="footer-brand">
        <Mark />
        <h2>
          Tastes <em>of</em> Africa
        </h2>
        <p>
          A celebration of the people, places and recipes shaping Africa’s
          living culinary story.
        </p>
      </div>
      <div className="footer-links">
        <span>Explore</span>
        <button onClick={() => go("recipes")}>Recipes</button>
        <button onClick={() => go("regions")}>Regions</button>
        <button onClick={() => go("about")}>Our story</button>
      </div>
      <div className="footer-links">
        <span>Follow</span>
        <a href="#instagram">Instagram</a>
        <a href="#pinterest">Pinterest</a>
        <a href="#youtube">YouTube</a>
      </div>
      <div className="footer-note">
        <span>
          From Africa,
          <br />
          with warmth.
        </span>
        <p>© 2025 Tastes of Africa</p>
      </div>
    </footer>
  )
}
